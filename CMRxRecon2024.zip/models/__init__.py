from monai.networks.nets import BasicUNet
from models.vit_pytorch.simple_vit_3d import SimpleViT
from .promptmr import PromptMR
from models import metric
from models import loss