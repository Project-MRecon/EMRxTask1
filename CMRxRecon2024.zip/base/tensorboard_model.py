import torch.nn as nn

class tensorboard_model():
    pass